from django.contrib.auth.models import AbstractUser
from django.db import models


class UserInfo(AbstractUser):
    """
    nick_name:昵称
    student_id:学号
    tel:手机号
    token:第三方登录的ID
    ip:IP地址
    addr:用户的地址
    name:姓名
    sex：性别
    national：民族

    """
    nid = models.AutoField(primary_key=True)
    student_id = models.CharField(max_length=32, verbose_name='学号', null=True, blank=True)
    nick_name = models.CharField(max_length=16, verbose_name='昵称', null=True, blank=True)
    tel = models.CharField(verbose_name='手机号', max_length=12, null=True, blank=True)
    token = models.CharField(verbose_name='id', help_text='其他平台的唯一登录id', max_length=64, null=True, blank=True)
    ip = models.GenericIPAddressField(verbose_name='ip地址', default='117.132.46.143')
    addr = models.CharField(max_length=8, verbose_name='用户地址信息', null=True, blank=True)
    name = models.CharField(max_length=8, verbose_name='姓名', null=True, blank=True)
    sex = models.CharField(max_length=2, verbose_name='性别', null=True, blank=True)
    national = models.CharField(max_length=8, verbose_name='民族', null=True, blank=True)

    class Meta:
        verbose_name_plural = '学生信息'






