from django.contrib import auth
from django.shortcuts import render, redirect
from app01.models import UserInfo


# Create your views here.
def index(request):
    return render(request, 'index.html')


def logout(request):
    auth.logout(request)
    return redirect('/')


def home(request):
    user_info = UserInfo.objects.filter(nid=request.user.nid).first()
    print(user_info.name)
    user_list = UserInfo.objects.all()
    return render(request, 'home.html', locals())


def userLur(request):
    return render(request, 'userLur.html')


def search_student(request):
    search_info = request.GET.get('key')
    student_list = UserInfo.objects.filter(name__contains=search_info)
    return render(request, 'search_student.html', locals())


def userupdate(request):
    nid = request.GET.get('nid')
    return render(request, 'userupdate.html', locals())


def userinfo(request):
    user_info = UserInfo.objects.filter(nid=request.user.nid).first()
    return render(request, 'userInfo.html', locals())


def welcome(request):
    return render(request, 'welcome.html')


def search(request):
    return render(request, 'search.html')