from django.contrib import admin
from app01.models import UserInfo


# Register your models here.

class UserInfoAdmin(admin.ModelAdmin):
    list_display = ['username', 'name', 'tel', 'sex', 'national']

    list_filter = ['name']


admin.site.register(UserInfo, UserInfoAdmin)

admin.site.site_header = '学生信息管理系统后台管理'

admin.site.site_title = '学生信息管理系统后台管理'
