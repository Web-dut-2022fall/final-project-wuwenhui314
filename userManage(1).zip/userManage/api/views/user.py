from django.views import View
from django.http import JsonResponse
from app01.models import UserInfo


class UserLurView(View):
    # def post(self, request):
    #     res = {
    #         'code': 201,
    #         'msg': '信息录入成功！',
    #         'data': None
    #     }
    #
    #     book_name = request.data.get('bookName')
    #     book_num = request.data.get('bookNum')
    #     # BookInfo.objects.create(bookName=book_name, bookNum=book_num)
    #     res['code'] = 200
    #     return JsonResponse(res)

    def delete(self, request):
        res = {
            'code': 201,
            'msg': '删除成功！'
        }
        nid = request.data.get('nid')
        user_query = UserInfo.objects.filter(nid=nid)
        user_query.delete()
        res['code'] = 200
        return JsonResponse(res)

    def put(self, request):
        res = {
            'code': 201,
            'msg': '修改成功！'
        }
        nid = request.data.get('nid')
        user_name = request.data.get('userName')
        user_sex = request.data.get('userSex')
        user_nation = request.data.get('userNation')
        user_id = request.data.get('userId')
        user_query = UserInfo.objects.filter(nid=nid)
        user_query.update(name=user_name, sex=user_sex, national=user_nation, student_id=user_id)
        res['code'] = 200
        return JsonResponse(res)
