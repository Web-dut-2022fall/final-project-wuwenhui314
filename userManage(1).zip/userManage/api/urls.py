from django.urls import path, re_path
from api.views import login, user

urlpatterns = [
    path('login/', login.LoginView.as_view()),
    path('sign/', login.SignView.as_view()),
    path('userlur/', user.UserLurView.as_view()),

]